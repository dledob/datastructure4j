public class LinkedPositionalList<E> implements PositionalList<E> {
//---------------- nested Node class ----------------
private static class Node<E> implements Position<E> {
private E element;
 // reference to the element stored at this node
private Node<E> prev;
 // reference to the previous node in the list
private Node<E> next;
 // reference to the subsequent node in the list
public Node(E e, Node<E> p, Node<E> n) {
element = e;
prev = p;
next = n;
}
public E getElement( ) throws IllegalStateException {
if (next == null)
 // convention for defunct node
throw new IllegalStateException("Position no longer valid");
return element;
}
public Node<E> getPrev( ) {
return prev;
}
public Node<E> getNext( ) {
return next;
}
public void setElement(E e) {
element = e;
}
public void setPrev(Node<E> p) {
prev = p;
}
public void setNext(Node<E> n) {
next = n;
}
} //----------- end of nested Node class -----------
// instance variables of the LinkedPositionalList
private Node<E> header;
 // header sentinel
private Node<E> trailer;
 // trailer sentinel
private int size = 0;
 // number of elements in the list
/∗∗ Constructs a new empty list. ∗/
public LinkedPositionalList( ) {
header = new Node<>(null, null, null);
 // create header
trailer = new Node<>(null, header, null);
 // trailer is preceded by header
header.setNext(trailer);
 // header is followed by trailer
}

